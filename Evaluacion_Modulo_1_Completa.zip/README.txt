EVALUACIÓN MÓDULO 1 — INSTRUCCIONES

1. Publica los archivos index.html + carpeta images/ en GitHub Pages.
2. Para guardar resultados, crea una Google Sheet y abre Extensiones > Apps Script.
3. Copia el contenido de google_apps_script.gs en Apps Script.
4. Implementa como Aplicación web: ejecutar como tú mismo; acceso: Cualquiera.
5. Copia la URL que termina en /exec.
6. Abre index.html y reemplaza PEGA_AQUI_LA_URL_DE_GOOGLE_APPS_SCRIPT por esa URL.
7. Sube el index.html actualizado a GitHub Pages.

La evaluación muestra al estudiante solamente si cada respuesta fue correcta o incorrecta y qué opción seleccionó. La respuesta correcta queda oculta.

NOTA: El documento original recibido contiene la numeración 1-9 y luego 11-30; no se incluyó una pregunta 10 porque no aparece en el archivo fuente.
