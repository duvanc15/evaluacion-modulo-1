/**
 * Google Apps Script para guardar los resultados de la evaluación.
 * 1) Crea una Google Sheet.
 * 2) Extensiones > Apps Script.
 * 3) Pega este código y guarda.
 * 4) Implementar > Nueva implementación > Aplicación web.
 * 5) Ejecutar como: Tú mismo.
 * 6) Quién tiene acceso: Cualquiera.
 * 7) Copia la URL /exec y pégala en index.html en CONFIG.APPS_SCRIPT_URL.
 */

function doGet() {
  return ContentService.createTextOutput('Servicio de resultados activo.');
}

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents || '{}');
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName('Resultados') || ss.insertSheet('Resultados');

    var questions = data.answers || [];
    if (sheet.getLastRow() === 0) {
      var headers = ['Fecha y hora', 'Nombre', 'Código / grupo', 'Puntaje', 'Total', 'Porcentaje'];
      questions.forEach(function(q){ headers.push('P' + q.question); });
      sheet.appendRow(headers);
      sheet.setFrozenRows(1);
    }

    var row = [
      new Date(),
      String(data.name || ''),
      String(data.code || ''),
      Number(data.score || 0),
      Number(data.total || 0),
      String(data.percentage || '') + '%'
    ];
    questions.forEach(function(q){
      row.push(String.fromCharCode(65 + Number(q.selected)));
    });
    sheet.appendRow(row);

    return ContentService
      .createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ok:false, error:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
